# 1. install python
 - please confirm you have python environment on your machine.
 - if not, please follow this: https://phoenixnap.com/kb/how-to-install-python-3-windows

# 2. install needed python libraries.
    - you can find `requirements.txt` file in this path.
    - open command terminal(cmd) in this path.
    - type `pip install -r requirements.txt`

    *you have to install chromdriver on your linux machin.

# 3. run script.
    - if you open the cmd here(if not, please open), type `scrapy crawl yahoospider`
      script will run.

# 4. find results
    - you can find output folder in this path.
    - in this, you can find `calls.json` file and `puts.json` file.
